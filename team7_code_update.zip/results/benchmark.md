# Benchmark

Macro F1 over the 7 discourse types (protocol: [docs/metrics_protocol.md](../docs/metrics_protocol.md)).
No row is filled until `src/evaluate.py` produced it; each filled row links its results JSON.

The most-frequent baseline reaches 53.35% token accuracy on test_seen but only
0.0321 span macro-F1: it labels tokens one by one, so it almost never forms a
complete span. This is why we rank by span F1, not token accuracy.

| # | Architecture | Specific model | Decoder | Seen: overlap F1 | Seen: exact F1 | Unseen: overlap F1 | Unseen: exact F1 | Results file |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Lookup | Most-frequent tag per word | Argmax | 0.0321 | 0.0001 | 0.0311 | 0.0000 | [seen](most_frequent_test_seen.json), [unseen](most_frequent_test_unseen.json) |
| 2 | Linear-chain CRF | sklearn-crfsuite, hand features | Viterbi | | | | | |
| 3 | BiLSTM | 2-layer BiLSTM, embeddings trained from scratch | CRF (constrained Viterbi) | | | | | |
| 4 | BERT | bert-base-cased | Softmax | | | | | |
| 5 | BERT | bert-base-cased | CRF | | | | | |
| 6 | DeBERTa | deberta-v3-base | CRF | | | | | |
